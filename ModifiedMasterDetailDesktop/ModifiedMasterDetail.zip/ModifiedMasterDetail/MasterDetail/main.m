//
//  main.m
//  MasterDetail
//
//  Created by jboyd on 3/18/14.
//  Copyright (c) 2014 jboyd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
